﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Azure.Storage;
using Azure.Storage.Files.DataLake;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Azure.KeyVault;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace WebAppConnectionToDataLake.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;

        private readonly IConfiguration _configuration;
        public IndexModel(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public void OnGet()
        {
            ViewData["config"] = _configuration["Storage:AccountName"];
            UploadToDataLake();
        }

        public void UploadToDataLake()
        {
            StorageSharedKeyCredential sharedKeyCredential = new StorageSharedKeyCredential(_configuration["storageAccountName"].ToString(), _configuration["storageAccountKey"].ToString());
            string dfsUri = "https://" + _configuration["storageAccountName"].ToString()  + ".dfs.core.windows.net";
            // Create DataLakeServiceClient using StorageSharedKeyCredentials
            DataLakeServiceClient serviceClient = new DataLakeServiceClient(new Uri(dfsUri), sharedKeyCredential);
            // Get a reference to a filesystem named "sample-filesystem-append" and then create it
            DataLakeFileSystemClient filesystem = serviceClient.GetFileSystemClient("sample-2");
            filesystem.Create();
            DataLakeDirectoryClient directory = filesystem.GetDirectoryClient("sample-file3");
            directory.Create();
        }

    }
}
